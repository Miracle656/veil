export declare enum BiometryType {
    None = 0,
    TouchID = 1,
    FaceID = 2,
    Iris = 3
}
export interface Status {
    isAvailable: boolean;
    biometryType: BiometryType;
    error?: string;
    errorCode?: 'appCancel' | 'authenticationFailed' | 'invalidContext' | 'notInteractive' | 'passcodeNotSet' | 'systemCancel' | 'userCancel' | 'userFallback' | 'biometryLockout' | 'biometryNotAvailable' | 'biometryNotEnrolled';
}
export interface AuthOptions {
    allowDeviceCredential?: boolean;
    cancelTitle?: string;
    fallbackTitle?: string;
    title?: string;
    subtitle?: string;
    confirmationRequired?: boolean;
    maxAttemps?: number;
}
/**
 * Checks if the biometric authentication is available.
 * @returns a promise resolving to an object containing all the information about the status of the biometry.
 */
export declare function checkStatus(): Promise<Status>;
/**
 * Prompts the user for authentication using the system interface (touchID, faceID or Android Iris).
 * Rejects if the authentication fails.
 *
 * ```javascript
 * import { authenticate } from "@tauri-apps/plugin-biometric";
 * await authenticate('Open your wallet');
 * ```
 * @param reason
 * @param options
 * @returns
 */
export declare function authenticate(reason: string, options?: AuthOptions): Promise<void>;
