import {
    Account,
    Contract,
    rpc as SorobanRpc,
    Horizon,
    StrKey,
    TransactionBuilder,
    BASE_FEE,
    xdr,
    nativeToScVal,
    scValToNative,
    Networks,
} from '@stellar/stellar-sdk';

const HorizonServer = Horizon.Server;
import { resolveSigner, signWith, type SignerInput } from './signer';
import {
    bufferToHex,
    hexToUint8Array,
    derToRawSignature,
    extractP256PublicKey,
    computeWalletAddress,
} from './utils';

// Re-export types from the main module
export type {
    WalletConfig,
    WebAuthnSignature,
    RegisterResult,
    DeployResult,
    AddSignerResult,
    SignerInfo,
    InitiateRecoveryResult,
} from './useInvisibleWallet';

import type {
    WalletConfig,
    WebAuthnSignature,
    RegisterResult,
    DeployResult,
    AddSignerResult,
    SignerInfo,
    InitiateRecoveryResult,
    LoginOptions,
} from './useInvisibleWallet';

// Custom error classes
class NoGuardianSet extends Error {
    constructor() {
        super('No guardian has been set for this wallet');
        this.name = 'NoGuardianSet';
    }
}

class RecoveryTimelockActive extends Error {
    constructor(expiresAt: number) {
        super(`Recovery timelock is active until ${new Date(expiresAt * 1000).toISOString()}`);
        this.name = 'RecoveryTimelockActive';
    }
}

class RecoveryNotPending extends Error {
    constructor() {
        super('No recovery is currently pending');
        this.name = 'RecoveryNotPending';
    }
}

const POLL_INTERVAL_MS = 1_000;
const POLL_MAX_ATTEMPTS = 30;

async function waitForTransaction(
    server: SorobanRpc.Server,
    hash: string
): Promise<SorobanRpc.Api.GetTransactionResponse> {
    for (let i = 0; i < POLL_MAX_ATTEMPTS; i++) {
        const result = await server.getTransaction(hash);
        if (result.status !== SorobanRpc.Api.GetTransactionStatus.NOT_FOUND) {
            return result;
        }
        await new Promise(r => setTimeout(r, POLL_INTERVAL_MS));
    }
    throw new Error(`Transaction ${hash} not confirmed after ${POLL_MAX_ATTEMPTS} attempts`);
}

export class InvisibleWallet {
    private config: WalletConfig;
    private _address: string | null = null;
    private _isDeployed = false;

    constructor(config: WalletConfig) {
        this.config = config;
        
        // Load address from localStorage if available
        const stored = localStorage.getItem('invisible_wallet_address');
        if (stored) this._address = stored;
    }

    get address(): string | null {
        return this._address;
    }

    get isDeployed(): boolean {
        return this._isDeployed;
    }

    async register(username?: string): Promise<RegisterResult> {
        const challenge = crypto.getRandomValues(new Uint8Array(32));
        const normalizedUsername = username ? username.normalize('NFC') : undefined;
        const name = normalizedUsername || 'Veil User';
        const userId = normalizedUsername ? new TextEncoder().encode(normalizedUsername) : crypto.getRandomValues(new Uint8Array(16));

        const credential = await navigator.credentials.create({
            publicKey: {
                challenge,
                rp: { name: 'Invisible Wallet' },
                user: {
                    id: userId,
                    name: name,
                    displayName: name,
                },
                pubKeyCredParams: [{ type: 'public-key', alg: -7 }],
                timeout: 60_000,
                authenticatorSelection: {
                    residentKey: 'preferred',
                    userVerification: 'required',
                },
            },
        }) as PublicKeyCredential;

        if (!credential?.response) {
            throw new Error('Failed to create WebAuthn credential');
        }

        const response = credential.response as AuthenticatorAttestationResponse;
        const publicKeyBytes = await extractP256PublicKey(response);
        const publicKeyHex = bufferToHex(publicKeyBytes);

        localStorage.setItem('invisible_wallet_pubkey', publicKeyHex);
        localStorage.setItem('invisible_wallet_credential_id', bufferToHex(new Uint8Array(credential.rawId)));

        const walletAddress = computeWalletAddress(
            this.config.factoryAddress,
            publicKeyBytes,
            this.config.networkPassphrase
        );

        this._address = walletAddress;
        localStorage.setItem('invisible_wallet_address', walletAddress);

        return {
            walletAddress,
            publicKeyBytes,
        };
    }

    async deploy(signerInput: SignerInput, publicKeyBytes?: Uint8Array): Promise<DeployResult> {
        const signer = resolveSigner(signerInput);
        
        const pubkeyBytes = publicKeyBytes || (() => {
            const stored = localStorage.getItem('invisible_wallet_pubkey');
            if (!stored) throw new Error('No public key found. Call register() first.');
            return hexToUint8Array(stored);
        })();

        const server = new SorobanRpc.Server(this.config.rpcUrl);
        const horizonServer = new HorizonServer(this.config.rpcUrl.replace('soroban-', ''));
        
        const walletAddress = computeWalletAddress(
            this.config.factoryAddress,
            pubkeyBytes,
            this.config.networkPassphrase
        );

        // Check if already deployed
        try {
            await server.getContractData(walletAddress, xdr.ScVal.scvLedgerKeyContractInstance());
            this._isDeployed = true;
            return { walletAddress, alreadyDeployed: true };
        } catch {
            // Not deployed yet, continue with deployment
        }

        const account = await horizonServer.loadAccount(signer.publicKey);
        const factory = new Contract(this.config.factoryAddress);

        const tx = new TransactionBuilder(account, {
            fee: BASE_FEE,
            networkPassphrase: this.config.networkPassphrase,
        })
            .addOperation(
                factory.call(
                    'deploy',
                    nativeToScVal(pubkeyBytes, { type: 'bytes' }),
                    nativeToScVal(this.config.rpId || window.location.hostname, { type: 'string' }),
                    nativeToScVal(this.config.origin || window.location.origin, { type: 'string' })
                )
            )
            .setTimeout(30)
            .build();

        const prepared = await server.prepareTransaction(tx);
        const signed = await signWith(prepared, signer, this.config.networkPassphrase);

        const result = await server.sendTransaction(signed);
        if (result.status === 'ERROR') {
            throw new Error(`Deploy failed: ${result.errorResult}`);
        }

        await waitForTransaction(server, result.hash);
        
        this._address = walletAddress;
        this._isDeployed = true;
        localStorage.setItem('invisible_wallet_address', walletAddress);

        return { walletAddress, alreadyDeployed: false };
    }

    async signAuthEntry(signaturePayload: Uint8Array): Promise<WebAuthnSignature | null> {
        const credentialIdHex = localStorage.getItem('invisible_wallet_credential_id');
        const publicKeyHex = localStorage.getItem('invisible_wallet_pubkey');

        if (!credentialIdHex || !publicKeyHex) {
            throw new Error('No credential found. Call register() first.');
        }

        const credentialIdBytes = hexToUint8Array(credentialIdHex);
        const assertion = await navigator.credentials.get({
            publicKey: {
                challenge: signaturePayload as BufferSource,
                allowCredentials: [{
                    type: 'public-key',
                    id: credentialIdBytes as BufferSource,
                }],
                userVerification: 'required',
                timeout: 60_000,
            },
        }) as PublicKeyCredential;

        if (!assertion?.response) return null;

        const response = assertion.response as AuthenticatorAssertionResponse;
        const rawSignature = derToRawSignature(response.signature);

        return {
            publicKey: hexToUint8Array(publicKeyHex) as Uint8Array,
            authData: new Uint8Array(response.authenticatorData) as Uint8Array,
            clientDataJSON: new Uint8Array(response.clientDataJSON) as Uint8Array,
            signature: rawSignature as Uint8Array,
        };
    }

    async login(options?: LoginOptions): Promise<{ walletAddress: string } | null> {
        const server = new SorobanRpc.Server(this.config.rpcUrl);

        // Path 1: local storage has an address (original behaviour)
        let candidateAddress = localStorage.getItem('invisible_wallet_address');

        // Path 2: caller supplied a known wallet address
        if (!candidateAddress && options?.walletAddress) {
            candidateAddress = options.walletAddress;
        }

        // Path 3: derive address from a passkey credential
        // NOTE: Vanilla mode cannot easily extract the public key from a bare
        // WebAuthn assertion without the SDK's webAuthnProvider abstraction.
        // When only a credentialId is provided, we attempt a direct assertion
        // and rely on the platform to surface the key.  For a reliable
        // cross-device login, prefer the React hook which has full
        // webAuthnProvider integration.
        if (!candidateAddress && options?.credentialId) {
            try {
                const credIdBytes = Uint8Array.from(
                    atob(options.credentialId.replace(/-/g, '+').replace(/_/g, '/')),
                    c => c.charCodeAt(0)
                );
                const assertion = await navigator.credentials.get({
                    publicKey: {
                        challenge: crypto.getRandomValues(new Uint8Array(32)),
                        allowCredentials: [{
                            type: 'public-key',
                            id: credIdBytes as BufferSource,
                        }],
                        userVerification: 'required',
                        timeout: 60_000,
                    },
                }) as PublicKeyCredential;

                if (assertion?.response) {
                    const response = assertion.response as AuthenticatorAssertionResponse;
                    // Try to extract the P-256 public key from the response
                    // getPublicKey() is not in the standard TS DOM typings but is
                    // supported by Chrome/Edge and some browsers on assertion responses.
                    const resp = response as any;
                    if (typeof resp.getPublicKey === 'function') {
                        const spkiBuffer: ArrayBuffer | null = resp.getPublicKey();
                        if (spkiBuffer) {
                            const cryptoKey = await crypto.subtle.importKey(
                                'spki', spkiBuffer,
                                { name: 'ECDSA', namedCurve: 'P-256' },
                                true, ['verify']
                            );
                            const rawBuffer = await crypto.subtle.exportKey('raw', cryptoKey);
                            const publicKeyBytes = new Uint8Array(rawBuffer);
                            if (publicKeyBytes.length === 65) {
                                candidateAddress = computeWalletAddress(
                                    this.config.factoryAddress,
                                    publicKeyBytes,
                                    this.config.networkPassphrase
                                );
                            }
                        }
                    }
                }
            } catch {
                // Assertion cancelled or public key not available
            }
        }

        if (!candidateAddress) return null;

        try {
            await server.getContractData(candidateAddress, xdr.ScVal.scvLedgerKeyContractInstance());
            this._address = candidateAddress;
            this._isDeployed = true;
            localStorage.setItem('invisible_wallet_address', candidateAddress);
            return { walletAddress: candidateAddress };
        } catch {
            return null;
        }
    }

    async getNonce(): Promise<bigint> {
        if (!this._address) throw new Error('No wallet address. Call register() and deploy() first.');

        const server = new SorobanRpc.Server(this.config.rpcUrl);
        const wallet = new Contract(this._address);
        
        const account = new Account('GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWHF', '0');
        const tx = new TransactionBuilder(account, {
            fee: BASE_FEE,
            networkPassphrase: this.config.networkPassphrase,
        })
            .addOperation(wallet.call('get_nonce'))
            .setTimeout(30)
            .build();

        const result = await server.simulateTransaction(tx);
        if (SorobanRpc.Api.isSimulationError(result)) {
            throw new Error(`Failed to get nonce: ${result.error}`);
        }

        return scValToNative(result.result!.retval);
    }

    // Additional methods would follow the same pattern...
    // For brevity, implementing core methods only
}

export function createInvisibleWallet(config: WalletConfig): InvisibleWallet {
    return new InvisibleWallet(config);
}
